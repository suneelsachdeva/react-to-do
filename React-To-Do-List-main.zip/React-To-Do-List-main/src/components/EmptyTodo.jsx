import React from 'react'
import Navigation from './Navigation'

function EmptyTodo() {
  return (
    <>
        
        <div>
            Empty Todo list!
        </div>
    </>
  )
}

export default EmptyTodo